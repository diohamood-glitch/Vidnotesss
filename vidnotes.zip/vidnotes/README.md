# VidNotes (prototype)

Android app to organize YouTube videos: playlists, notes with video thumbnails, sketches saved inside notes,
in-app YouTube playback, separate tabs, and cloud storage (Firebase).

## Build the APK
**Option A — GitHub (no install):** push this folder to a new GitHub repo, open the **Actions** tab, run
**Build APK**, then download `vidnotes-debug-apk` (contains `app-debug.apk`).

**Option B — Android Studio:** open this folder, wait for Gradle sync, then **Build → Build APK(s)**.
Output: `app/build/outputs/apk/debug/app-debug.apk`. (CLI: `gradle assembleDebug` with Gradle 8.7+, JDK 17 and the Android SDK.)

Install on your phone: copy the APK over and allow "install unknown apps".

## Cloud setup (Firebase, free plan)
1. Create a project at console.firebase.google.com.
2. Authentication → enable **Email/Password**.
3. Firestore Database → create database, then paste these rules:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{db}/documents {
    match /users/{uid}/{doc=**} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```
4. In the app's **Cloud** tab enter the Project ID + Web API key, then create an account.
   (Or put them in `app/src/main/assets/www/config.js` before building.)

## Features
- **Videos:** paste a link or use Share → VidNotes from the YouTube app; tap a thumbnail to play in-app.
- **Playlists:** create, reorder, play all with next/previous and auto-advance.
- **Notes:** text, timestamp comments (jump back to the moment), attached videos, sketches.
- **Sketch tool:** pen, marker, eraser, colors, size, undo/redo; saved inside the note, re-editable.
- **Cloud:** offline-first; syncs to your Firebase project; newest edit wins.

## Layout
`app/src/main/java/.../MainActivity.java` is a WebView shell; the UI is in `app/src/main/assets/www/`.
