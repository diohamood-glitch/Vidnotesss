/* VidNotes — YouTube organizer: videos, playlists, notes with sketches, cloud sync (Firebase REST). */
(function () {
'use strict';

/* ---------- helpers ---------- */
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : 'id' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
const now = () => Date.now();
const thumbUrl = yt => `https://i.ytimg.com/vi/${yt}/hqdefault.jpg`;
const fmtT = s => { s = Math.max(0, Math.floor(s || 0)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}` : `${m}:${String(x).padStart(2, '0')}`; };

const ICONS = {
  play: 'M8 5v14l11-7z',
  video: 'M17 10.5V7a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3.5l4 4v-11z',
  list: 'M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z',
  note: 'M3 18h12v-2H3v2zM3 6v2h18V6H3zm0 7h18v-2H3v2z',
  cloud: 'M19.35 10.04A7.49 7.49 0 0 0 12 4C9.11 4 6.6 5.64 5.35 8.04A5.994 5.994 0 0 0 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z',
  plus: 'M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z',
  trash: 'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z',
  close: 'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z',
  back: 'M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z',
  up: 'M7.41 15.41L12 10.83l4.59 4.58L18 14l-6-6-6 6z',
  down: 'M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6z',
  more: 'M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z',
  brush: 'M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a.996.996 0 0 0 0-1.41l-2.34-2.34a.996.996 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z',
  undo: 'M12.5 8c-2.65 0-5.05.99-6.9 2.6L2 7v9h9l-3.62-3.62c1.39-1.16 3.16-1.88 5.12-1.88 3.54 0 6.55 2.31 7.6 5.5l2.37-.78C21.08 11.03 17.15 8 12.5 8z',
  redo: 'M18.4 10.6C16.55 8.99 14.15 8 11.5 8c-4.65 0-8.58 3.03-9.96 7.22L3.9 16c1.05-3.19 4.05-5.5 7.6-5.5 1.95 0 3.73.72 5.12 1.88L13 16h9V7l-3.6 3.6z',
  check: 'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z',
  clock: 'M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z',
  text: 'M5 4v3h5.5v12h3V7H19V4z',
  sync: 'M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46A7.93 7.93 0 0 0 20 12c0-4.42-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74A7.93 7.93 0 0 0 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3z',
  eraser: 'M16.24 3.56l4.95 4.94c.78.79.78 2.05 0 2.84L12 20.53a4.008 4.008 0 0 1-5.66 0L2.81 17c-.78-.79-.78-2.05 0-2.84l10.6-10.6c.79-.78 2.05-.78 2.83 0zM4.22 15.58l3.54 3.53c.78.79 2.04.79 2.83 0l3.53-3.53-4.95-4.95-4.95 4.95z',
  next: 'M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z',
  prev: 'M6 6h2v12H6zm3.5 6l8.5 6V6z',
  size: 'M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z',
  ext: 'M19 19H5V5h7V3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z',
  pladd: 'M14 10H2v2h12v-2zm0-4H2v2h12V6zm4 8v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zM2 16h8v-2H2v2z',
  edit: 'M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25z'
};
const ic = n => `<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="${ICONS[n] || ''}"/></svg>`;

function toast(msg, ms) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), ms || 2600);
}

/* ---------- storage (IndexedDB, with localStorage fallback) ---------- */
const DB = {
  db: null,
  open() {
    return new Promise(res => {
      try {
        const rq = indexedDB.open('vidnotes', 1);
        rq.onupgradeneeded = () => rq.result.createObjectStore('kv');
        rq.onsuccess = () => { DB.db = rq.result; res(); };
        rq.onerror = () => res();
      } catch (e) { res(); }
    });
  },
  get(k) {
    return new Promise(res => {
      if (!DB.db) { try { res(JSON.parse(localStorage.getItem('vn.' + k))); } catch (e) { res(null); } return; }
      const r = DB.db.transaction('kv').objectStore('kv').get(k);
      r.onsuccess = () => res(r.result == null ? null : r.result);
      r.onerror = () => res(null);
    });
  },
  set(k, v) {
    return new Promise(res => {
      if (!DB.db) { try { localStorage.setItem('vn.' + k, JSON.stringify(v)); } catch (e) { toast('Storage is full'); } res(); return; }
      const tx = DB.db.transaction('kv', 'readwrite'); tx.objectStore('kv').put(v, k);
      tx.oncomplete = () => res(); tx.onerror = () => res();
    });
  }
};

/* ---------- state ---------- */
let data = { videos: [], playlists: [], notes: [] };
let cfg = { apiKey: '', projectId: '' };
let auth = null;                       // {email, uid, idToken, refreshToken, exp}
let syncMeta = { last: 0, dirty: false, error: '' };
let tab = 'videos';
let miniPref = null;                   // null = automatic
let openPl = null;                     // playlist id shown in overlay
let editId = null;                     // note id in editor
let playCtx = { videoId: null, plId: null };
let vFilter = '', nFilter = '';

const alive = arr => arr.filter(x => !x.deleted);
const vid = id => data.videos.find(v => v.id === id);
const pl = id => data.playlists.find(p => p.id === id);
const note = id => data.notes.find(n => n.id === id);

let saveT = null;
function persist() { return DB.set('data', data); }
function save() {
  syncMeta.dirty = true; renderChip();
  clearTimeout(saveT); saveT = setTimeout(() => { persist(); DB.set('meta', syncMeta); scheduleSync(); }, 300);
}
const touch = o => { o.updatedAt = now(); save(); };

/* ---------- YouTube link parsing + metadata ---------- */
function parseYT(text) {
  if (!text) return null;
  const m = String(text).match(/(?:youtu\.be\/|youtube(?:-nocookie)?\.com\/(?:watch\?(?:[^\s#]*&)?v=|shorts\/|embed\/|live\/|v\/)|music\.youtube\.com\/watch\?(?:[^\s#]*&)?v=)([A-Za-z0-9_-]{11})/i);
  let yt = m && m[1];
  if (!yt) { const b = String(text).trim().match(/^([A-Za-z0-9_-]{11})$/); yt = b && b[1]; }
  if (!yt) return null;
  let t = 0;
  const tm = String(text).match(/[?&#](?:t|start)=([0-9hms]+)/i);
  if (tm) {
    const s = tm[1];
    if (/^\d+$/.test(s)) t = +s;
    else { const r = s.match(/(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?/i); t = (+r[1] || 0) * 3600 + (+r[2] || 0) * 60 + (+r[3] || 0); }
  }
  return { yt, t };
}

async function fetchMeta(yt) {
  try {
    const url = 'https://www.youtube.com/oembed?format=json&url=' + encodeURIComponent('https://www.youtube.com/watch?v=' + yt);
    const r = await fetch(url);
    if (!r.ok) throw new Error('oembed ' + r.status);
    const j = await r.json();
    return { title: j.title || '', author: j.author_name || '' };
  } catch (e) { return { title: '', author: '' }; }
}

async function addVideoFromText(text, silent) {
  const p = parseYT(text);
  if (!p) { toast('That doesn\'t look like a YouTube link'); return null; }
  const ex = data.videos.find(v => v.yt === p.yt && !v.deleted);
  if (ex) { if (!silent) toast('Already in your videos'); return ex; }
  const v = { id: uid(), yt: p.yt, title: 'Loading title…', author: '', addedAt: now(), updatedAt: now() };
  data.videos.push(v); save(); renderAll();
  const m = await fetchMeta(p.yt);
  v.title = m.title || ('YouTube video ' + p.yt); v.author = m.author; touch(v); renderAll();
  if (!silent) toast('Video added');
  return v;
}

/* ---------- player ---------- */
let player = null, playerReady = false, ytLoading = null;
function loadYT() {
  if (window.YT && YT.Player) return Promise.resolve(true);
  if (ytLoading) return ytLoading;
  ytLoading = new Promise(res => {
    const prev = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => { if (prev) prev(); res(true); };
    const s = document.createElement('script'); s.src = 'https://www.youtube.com/iframe_api';
    s.onerror = () => { ytLoading = null; res(false); };
    document.head.appendChild(s);
    setTimeout(() => { if (!(window.YT && YT.Player)) { ytLoading = null; res(false); } }, 12000);
  });
  return ytLoading;
}

async function play(videoId, plId, start) {
  const v = vid(videoId); if (!v) return;
  playCtx = { videoId, plId: plId || null };
  $('#dock').hidden = false;
  renderDock(); renderAll(true);
  const ok = await loadYT();
  if (!ok) { toast('Can\'t reach YouTube. Check your connection.'); return; }
  start = start || 0;
  if (player && playerReady) { player.loadVideoById({ videoId: v.yt, startSeconds: start }); return; }
  if (player) return;
  player = new YT.Player('yt', {
    videoId: v.yt, host: 'https://www.youtube.com',
    playerVars: { playsinline: 1, rel: 0, modestbranding: 1, start: start, autoplay: 1, origin: location.origin },
    events: {
      onReady: e => { playerReady = true; e.target.playVideo(); },
      onStateChange: e => { if (e.data === 0) nextInList(1, true); },
      onError: () => {
        const cv = vid(playCtx.videoId);
        $('#dockSub').innerHTML = 'This video can\'t be played in-app. ' + (cv ? `<a href="https://www.youtube.com/watch?v=${esc(cv.yt)}" target="_blank">Open in YouTube</a>` : '');
      }
    }
  });
}

function listForCtx() {
  if (!playCtx.plId) return null;
  const p = pl(playCtx.plId); if (!p) return null;
  return p.items.filter(id => { const v = vid(id); return v && !v.deleted; });
}
function nextInList(dir, auto) {
  const l = listForCtx();
  if (!l || !l.length) { if (!auto) toast('Not playing from a playlist'); return; }
  const i = l.indexOf(playCtx.videoId);
  const j = i + dir;
  if (j < 0 || j >= l.length) { if (auto) return; toast(dir > 0 ? 'End of playlist' : 'Start of playlist'); return; }
  play(l[j], playCtx.plId);
}
function stopPlayer() {
  try { if (player && player.destroy) player.destroy(); } catch (e) { /* ignore */ }
  player = null; playerReady = false; playCtx = { videoId: null, plId: null };
  const dock = $('#dock'); dock.hidden = true;
  const old = $('#ytWrap'); old.innerHTML = '<div id="yt"></div>';
  renderAll(true);
}
function currentTime() { try { return player && playerReady ? player.getCurrentTime() : 0; } catch (e) { return 0; } }

function isMini() {
  if (miniPref !== null) return miniPref;
  return tab !== 'videos' || !$('#plView').hidden || !$('#noteView').hidden;
}
function renderDock() {
  const v = vid(playCtx.videoId); if (!v) return;
  const dock = $('#dock');
  dock.classList.toggle('mini', isMini());
  $('#dockTitle').textContent = v.title;
  const l = listForCtx();
  $('#dockSub').textContent = l ? `${pl(playCtx.plId).name} · ${l.indexOf(v.id) + 1}/${l.length}` : (v.author || '');
  $('#dockBtns').innerHTML =
    (l ? `<button data-action="dock-prev" aria-label="Previous">${ic('prev')}</button><button data-action="dock-next" aria-label="Next">${ic('next')}</button>` : '') +
    `<button data-action="dock-size" aria-label="Resize">${ic('size')}</button><button data-action="dock-close" aria-label="Close player">${ic('close')}</button>`;
}

/* ---------- sheets ---------- */
function sheet(title, html, mount) {
  const w = document.createElement('div'); w.className = 'sheet-wrap';
  w.innerHTML = `<div class="sheet-back"></div><div class="sheet"><div class="sheet-h"><h3>${esc(title)}</h3><button class="icon" data-x aria-label="Close">${ic('close')}</button></div><div class="sheet-b">${html}</div></div>`;
  $('#sheetRoot').appendChild(w);
  const close = () => w.remove();
  $('.sheet-back', w).onclick = close; $('[data-x]', w).onclick = close;
  if (mount) mount($('.sheet-b', w), close);
  return close;
}
function confirmSheet(msg, okLabel, onOk) {
  sheet('Are you sure?', `<p style="margin:4px 0 14px">${esc(msg)}</p><div class="two" style="display:flex;gap:8px"><button class="btn" data-no style="flex:1">Cancel</button><button class="btn primary" data-ok style="flex:1">${esc(okLabel)}</button></div>`,
    (b, close) => { $('[data-no]', b).onclick = close; $('[data-ok]', b).onclick = () => { close(); onOk(); }; });
}
function promptSheet(title, label, value, okLabel, onOk) {
  sheet(title, `<form class="sform"><input type="text" id="pv" placeholder="${esc(label)}" value="${esc(value || '')}" maxlength="120"><button class="btn primary block">${esc(okLabel)}</button></form>`,
    (b, close) => {
      const inp = $('#pv', b); setTimeout(() => { inp.focus(); inp.select(); }, 80);
      $('form', b).onsubmit = e => { e.preventDefault(); const val = inp.value.trim(); if (!val) return; close(); onOk(val); };
    });
}
function pickPlaylistSheet(videoId) {
  const lists = alive(data.playlists);
  sheet('Add to playlist', `${lists.map(p => `<button class="prow ${p.items.includes(videoId) ? 'sel' : ''}" data-p="${p.id}"><span class="pico">${ic('list')}</span><span>${esc(p.name)}</span><span class="chk">${ic('check')}</span></button>`).join('')}
    <button class="prow" data-newp><span class="pico">${ic('plus')}</span><span>New playlist…</span></button>`,
    (b, close) => {
      $$('[data-p]', b).forEach(el => el.onclick = () => {
        const p = pl(el.dataset.p);
        if (p.items.includes(videoId)) { p.items = p.items.filter(x => x !== videoId); el.classList.remove('sel'); }
        else { p.items.push(videoId); el.classList.add('sel'); }
        touch(p); renderAll();
      });
      $('[data-newp]', b).onclick = () => { close(); promptSheet('New playlist', 'Playlist name', '', 'Create', name => {
        const p = { id: uid(), name, items: [videoId], updatedAt: now() }; data.playlists.push(p); save(); renderAll(); toast('Added to "' + name + '"'); }); };
    });
}
function pickVideoSheet(onPick) {
  const vs = alive(data.videos).sort((a, b) => b.addedAt - a.addedAt);
  sheet('Choose a video', vs.length ? vs.map(v => `<button class="prow" data-v="${v.id}"><img src="${thumbUrl(v.yt)}" alt=""><span>${esc(v.title)}</span></button>`).join('')
    : '<div class="empty">Add videos in the Videos tab first.</div>',
    (b, close) => $$('[data-v]', b).forEach(el => el.onclick = () => { close(); onPick(el.dataset.v); }));
}

/* ---------- rendering ---------- */
function renderChip() {
  const c = $('#syncChip');
  let st = 'off', label = 'Local only', icon = 'cloud';
  if (auth) {
    if (syncMeta.error) { st = 'error'; label = 'Sync error'; }
    else if (syncing) { st = 'syncing'; label = 'Syncing…'; icon = 'sync'; }
    else if (syncMeta.dirty) { st = 'pending'; label = 'Not synced'; }
    else { st = 'ok'; label = 'Synced'; }
  }
  c.className = 'chip ' + st; c.innerHTML = ic(icon) + esc(label);
}

function emptyState(icon, title, text) { return `<div class="empty">${ic(icon)}<b>${esc(title)}</b>${esc(text)}</div>`; }

function renderVideos() {
  let list = alive(data.videos).sort((a, b) => b.addedAt - a.addedAt);
  $('#vSearch').hidden = list.length < 6;
  if (vFilter) list = list.filter(v => (v.title + ' ' + v.author).toLowerCase().includes(vFilter));
  $('#vList').innerHTML = list.length ? list.map(v => `
    <div class="vcard ${playCtx.videoId === v.id ? 'playing' : ''}">
      <button class="thumb" data-action="play" data-id="${v.id}" aria-label="Play"><img src="${thumbUrl(v.yt)}" loading="lazy" alt=""><span class="playbadge">${ic('play')}</span></button>
      <div class="vmeta"><div class="vtitle">${esc(v.title)}</div><div class="vauthor">${esc(v.author)}</div>
        <div class="vbtns">
          <button data-action="vid-pl" data-id="${v.id}" aria-label="Add to playlist">${ic('pladd')}</button>
          <button data-action="vid-note" data-id="${v.id}" aria-label="New note">${ic('note')}</button>
          <button data-action="vid-del" data-id="${v.id}" aria-label="Delete">${ic('trash')}</button>
        </div></div>
    </div>`).join('')
    : (vFilter ? emptyState('video', 'No matches', 'Try another search.') : emptyState('video', 'No videos yet', 'Paste a YouTube link above, or share a video to VidNotes from the YouTube app.'));
}

function renderPlaylists() {
  const lists = alive(data.playlists).sort((a, b) => b.updatedAt - a.updatedAt);
  $('#pList').innerHTML = lists.length ? lists.map(p => {
    const items = p.items.map(vid).filter(v => v && !v.deleted);
    const cover = items[0] ? `<img src="${thumbUrl(items[0].yt)}" alt="">` : ic('list');
    return `<div class="pcard" data-action="open-pl" data-id="${p.id}"><div class="pcover">${cover}</div>
      <div class="pinfo"><div class="pname">${esc(p.name)}</div><div class="psub">${items.length} video${items.length === 1 ? '' : 's'}</div></div></div>`;
  }).join('') : emptyState('list', 'No playlists yet', 'Create one, then add videos to it from the Videos tab.');
}

function renderPlView() {
  const view = $('#plView');
  const p = openPl && pl(openPl);
  if (!p || p.deleted) { view.hidden = true; openPl = null; return; }
  view.hidden = false;
  const items = p.items.filter(id => { const v = vid(id); return v && !v.deleted; });
  view.innerHTML = `<div class="ovhead"><button class="icon" data-action="pl-close" aria-label="Back">${ic('back')}</button><h2>${esc(p.name)}</h2>
      <button class="icon" data-action="pl-rename" aria-label="Rename">${ic('edit')}</button><button class="icon" data-action="pl-del" aria-label="Delete">${ic('trash')}</button></div>
    <div class="plactions"><button class="btn primary" data-action="pl-play">${ic('play')} Play all</button><button class="btn" data-action="pl-note">${ic('note')} New note</button></div>
    <div class="ovbody">${items.length ? items.map((id, i) => { const v = vid(id); return `
      <div class="pitem ${playCtx.videoId === id && playCtx.plId === p.id ? 'playing' : ''}">
        <div class="idx">${i + 1}</div>
        <button class="thumb" data-action="play-in-pl" data-id="${id}"><img src="${thumbUrl(v.yt)}" loading="lazy" alt=""><span class="playbadge">${ic('play')}</span></button>
        <div class="vmeta"><div class="vtitle">${esc(v.title)}</div><div class="vauthor">${esc(v.author)}</div></div>
        <div class="col"><button data-action="pl-up" data-id="${id}" ${i === 0 ? 'disabled' : ''} aria-label="Move up">${ic('up')}</button>
          <button data-action="pl-down" data-id="${id}" ${i === items.length - 1 ? 'disabled' : ''} aria-label="Move down">${ic('down')}</button></div>
        <button class="icon" data-action="pl-rm" data-id="${id}" aria-label="Remove">${ic('close')}</button>
      </div>`; }).join('') : emptyState('video', 'Empty playlist', 'Open the Videos tab and tap the playlist button on a video.')}</div>`;
}

function noteText(n) { return n.blocks.filter(b => b.type === 'text').map(b => b.text).join(' ').replace(/\s+/g, ' ').trim(); }
function renderNotes() {
  let list = alive(data.notes).sort((a, b) => b.updatedAt - a.updatedAt);
  if (nFilter) list = list.filter(n => (n.title + ' ' + noteText(n) + ' ' + n.blocks.filter(b => b.type === 'ts').map(b => b.text).join(' ')).toLowerCase().includes(nFilter));
  $('#nList').innerHTML = list.length ? list.map(n => {
    const v = n.videoId && vid(n.videoId);
    const sk = n.blocks.find(b => b.type === 'sketch');
    const nSk = n.blocks.filter(b => b.type === 'sketch').length, nTs = n.blocks.filter(b => b.type === 'ts').length;
    const cover = v ? `<img src="${thumbUrl(v.yt)}" alt="">` : (sk ? `<img src="${sk.img}" alt="">` : ic('note'));
    return `<div class="ncard" data-action="open-note" data-id="${n.id}"><div class="pcover">${cover}</div>
      <div class="pinfo"><div class="pname">${esc(n.title || 'Untitled note')}</div><div class="nsnip">${esc(noteText(n) || (v ? v.title : 'Empty note'))}</div>
      <div class="nmeta">${nSk ? `<span>${ic('brush')}${nSk}</span>` : ''}${nTs ? `<span>${ic('clock')}${nTs}</span>` : ''}<span>${new Date(n.updatedAt).toLocaleDateString()}</span></div></div></div>`;
  }).join('') : (nFilter ? emptyState('note', 'No matches', 'Try another search.') : emptyState('note', 'No notes yet', 'Tap + to write a note, attach a video and draw sketches.'));
}

function blockHtml(b) {
  const more = `<button class="more" data-action="blk-more" data-b="${b.id}" aria-label="Block options">${ic('more')}</button>`;
  if (b.type === 'text') return `<div class="blk blk-text" data-b="${b.id}"><textarea data-blk="${b.id}" rows="1" placeholder="Write something…">${esc(b.text)}</textarea>${more}</div>`;
  if (b.type === 'sketch') return `<div class="blk blk-sketch" data-b="${b.id}"><button class="skwrap" data-action="edit-sketch" data-b="${b.id}" aria-label="Edit sketch"><img src="${b.img}" alt="Sketch"></button>${more}</div>`;
  const v = vid(b.videoId);
  if (b.type === 'ts') return `<div class="blk blk-ts" data-b="${b.id}">
      <button class="thumb" data-action="play-ts" data-b="${b.id}" aria-label="Jump to ${fmtT(b.t)}">${v ? `<img src="${thumbUrl(v.yt)}" alt="">` : ''}<span class="tsbadge">${ic('clock')}${fmtT(b.t)}</span></button>
      <input type="text" data-ts="${b.id}" placeholder="Comment at ${fmtT(b.t)}" value="${esc(b.text)}">${more}</div>`;
  if (b.type === 'video') return `<div class="blk blk-video" data-b="${b.id}">
      <button class="thumb" data-action="play-blk" data-b="${b.id}">${v ? `<img src="${thumbUrl(v.yt)}" alt="">` : ''}<span class="playbadge">${ic('play')}</span></button>
      <div class="vmeta"><div class="vtitle">${esc(v ? v.title : 'Video')}</div><div class="vauthor">${esc(v ? v.author : '')}</div></div>${more}</div>`;
  return '';
}

function renderNote(focusLast) {
  const view = $('#noteView');
  const n = editId && note(editId);
  if (!n) { view.hidden = true; editId = null; return; }
  const prevBody = $('#nBody'), sc = prevBody ? prevBody.scrollTop : 0;
  view.hidden = false;
  const v = n.videoId && vid(n.videoId);
  view.innerHTML = `<div class="ovhead"><button class="icon" data-action="note-close" aria-label="Back">${ic('back')}</button>
      <input class="title-in" id="nTitle" type="text" placeholder="Note title" value="${esc(n.title)}" maxlength="140">
      <button class="icon" data-action="note-more" aria-label="More">${ic('more')}</button></div>
    <div class="ovbody" id="nBody">
      ${v ? `<div class="nvid"><button class="thumb" data-action="play-note" aria-label="Play"><img src="${thumbUrl(v.yt)}" alt=""><span class="playbadge">${ic('play')}</span></button>
        <div class="vmeta"><div class="vtitle">${esc(v.title)}</div><div class="vauthor">${esc(v.author)}</div></div></div>`
        : `<button class="attach" data-action="note-attach">${ic('video')} Attach a video to this note</button>`}
      ${n.blocks.map(blockHtml).join('')}
      ${n.blocks.length ? '' : '<div class="empty" style="padding:20px">Use the buttons below to add text, a sketch or a timestamp.</div>'}
    </div>
    <div class="nbar"><button data-action="add-text">${ic('text')}Text</button><button data-action="add-sketch">${ic('brush')}Sketch</button>
      <button data-action="add-ts">${ic('clock')}Timestamp</button><button data-action="add-video">${ic('video')}Video</button></div>`;
  $$('textarea', view).forEach(autosize);
  const body = $('#nBody'); body.scrollTop = sc;
  if (focusLast) { const ta = $$('textarea', view).pop(); if (ta) { ta.focus(); body.scrollTop = body.scrollHeight; } }
}
function autosize(ta) { ta.style.height = 'auto'; ta.style.height = ta.scrollHeight + 'px'; }

const TABS = [['videos', 'video', 'Videos'], ['playlists', 'list', 'Playlists'], ['notes', 'note', 'Notes'], ['cloud', 'cloud', 'Cloud']];
function renderTabbar() {
  $$('#tabbar button').forEach((b, i) => { b.innerHTML = ic(TABS[i][1]) + `<span>${TABS[i][2]}</span>`; b.classList.toggle('on', TABS[i][0] === tab); });
  $('#barTitle').textContent = { videos: 'Videos', playlists: 'Playlists', notes: 'Notes', cloud: 'Cloud' }[tab];
}
function renderAll(keepEditor) {
  renderChip(); renderVideos(); renderPlaylists(); renderNotes();
  if (!$('#plView').hidden) renderPlView();
  if (!keepEditor && !$('#noteView').hidden) renderNote();
  if (tab === 'cloud') renderCloud();
  if (playCtx.videoId) renderDock();
}
function setTab(t) {
  tab = t; miniPref = null;
  $$('.tab').forEach(s => s.hidden = s.id !== 'tab-' + t);
  renderTabbar(); if (t === 'cloud') renderCloud();
  if (playCtx.videoId) renderDock();
}

/* ---------- notes logic ---------- */
function newNote(videoId, openAfter) {
  const n = { id: uid(), title: '', videoId: videoId || (playCtx.videoId || null), blocks: [], created: now(), updatedAt: now() };
  data.notes.push(n); save(); openNote(n.id, true); return n;
}
function openNote(id, focus) {
  editId = id; miniPref = null; renderNote(focus); renderNotes(); if (playCtx.videoId) renderDock();
}
function closeNote() {
  const n = editId && note(editId);
  if (n && !n.title.trim() && !n.videoId && !n.blocks.some(b => b.type !== 'text' || b.text.trim())) { n.deleted = true; touch(n); }
  editId = null; $('#noteView').hidden = true; $('#noteView').innerHTML = '';
  renderNotes(); if (playCtx.videoId) renderDock();
}
const blk = id => { const n = note(editId); return n && n.blocks.find(b => b.id === id); };

function addTimestamp() {
  const n = note(editId); if (!n) return;
  const vId = playCtx.videoId || n.videoId;
  if (!vId) { toast('Play a video or attach one to the note first'); return; }
  const t = playCtx.videoId && player ? Math.floor(currentTime()) : 0;
  if (!n.videoId) n.videoId = vId;
  n.blocks.push({ id: uid(), type: 'ts', videoId: vId, t, text: '' });
  touch(n); renderNote(); const inp = $$('[data-ts]').pop(); if (inp) inp.focus();
}

/* ---------- sketch editor ---------- */
const SK = { W: 1000, H: 750, colors: ['#111111', '#e11d2e', '#2563eb', '#16a34a', '#f59e0b', '#9333ea', '#ffffff'] };
function openSketch(initialImg, onSave) {
  const root = $('#sketchView'); root.hidden = false; document.body.classList.add('noscroll');
  let tool = 'pen', color = SK.colors[0], size = 6, dirty = false;
  const undo = [], redo = [];
  root.innerHTML = `<div class="skhead"><button class="icon" id="skX" aria-label="Close">${ic('close')}</button><div class="ttl">Sketch</div>
      <button class="icon" id="skUndo" aria-label="Undo">${ic('undo')}</button><button class="icon" id="skRedo" aria-label="Redo">${ic('redo')}</button>
      <button class="btn primary sm" id="skSave">${ic('check')} Save</button></div>
    <div id="skStage"><canvas id="skCanvas" width="${SK.W}" height="${SK.H}"></canvas></div>
    <div class="sktools"><div class="skrow">
        <button class="seg on" data-tool="pen">Pen</button><button class="seg" data-tool="hl">Marker</button><button class="seg" data-tool="eraser">Eraser</button>
        <button class="seg" id="skClear">Clear</button></div>
      <div class="skrow">${SK.colors.map((c, i) => `<button class="sw ${i === 0 ? 'on' : ''}" data-color="${c}" style="background:${c}" aria-label="Color ${c}"></button>`).join('')}
        <input type="range" id="skSize" min="2" max="40" value="6" aria-label="Brush size"></div></div>`;
  const cv = $('#skCanvas'), ctx = cv.getContext('2d', { willReadFrequently: true });
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, SK.W, SK.H);
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  if (initialImg) { const im = new Image(); im.onload = () => { ctx.drawImage(im, 0, 0, SK.W, SK.H); }; im.src = initialImg; }

  const fit = () => {
    const st = $('#skStage'); if (!st) return;
    const w = st.clientWidth - 16, h = st.clientHeight - 16; let cw = w, ch = w * SK.H / SK.W;
    if (ch > h) { ch = h; cw = h * SK.W / SK.H; }
    cv.style.width = Math.max(50, cw) + 'px'; cv.style.height = Math.max(50, ch) + 'px';
  };
  fit(); const onResize = () => fit(); window.addEventListener('resize', onResize);
  const btns = () => { $('#skUndo').disabled = !undo.length; $('#skRedo').disabled = !redo.length; };
  btns();
  const snap = () => ctx.getImageData(0, 0, SK.W, SK.H);
  const pushUndo = () => { undo.push(snap()); if (undo.length > 25) undo.shift(); redo.length = 0; btns(); };

  let pts = [], base = null, drawing = false;
  const pos = e => { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left) * SK.W / r.width, y: (e.clientY - r.top) * SK.H / r.height }; };
  const strokeStyle = () => {
    ctx.globalAlpha = tool === 'hl' ? 0.35 : 1;
    ctx.strokeStyle = tool === 'eraser' ? '#ffffff' : color;
    ctx.lineWidth = tool === 'hl' ? size * 3 : (tool === 'eraser' ? size * 3 : size);
  };
  const drawPts = () => {
    ctx.putImageData(base, 0, 0); strokeStyle();
    ctx.beginPath();
    if (pts.length === 1) { ctx.arc(pts[0].x, pts[0].y, ctx.lineWidth / 2, 0, Math.PI * 2); ctx.fillStyle = ctx.strokeStyle; ctx.fill(); }
    else {
      ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length - 1; i++) { const mx = (pts[i].x + pts[i + 1].x) / 2, my = (pts[i].y + pts[i + 1].y) / 2; ctx.quadraticCurveTo(pts[i].x, pts[i].y, mx, my); }
      const l = pts[pts.length - 1]; ctx.lineTo(l.x, l.y); ctx.stroke();
    }
    ctx.globalAlpha = 1;
  };
  cv.addEventListener('pointerdown', e => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    e.preventDefault(); cv.setPointerCapture(e.pointerId);
    pushUndo(); base = snap(); drawing = true; pts = [pos(e)]; drawPts();
  });
  cv.addEventListener('pointermove', e => {
    if (!drawing) return; e.preventDefault();
    const evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
    (evs.length ? evs : [e]).forEach(ev => pts.push(pos(ev))); drawPts();
  });
  const end = () => { if (drawing) { drawing = false; dirty = true; } };
  cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);

  $$('[data-tool]', root).forEach(b => b.onclick = () => { tool = b.dataset.tool; $$('[data-tool]', root).forEach(x => x.classList.toggle('on', x === b)); });
  $$('[data-color]', root).forEach(b => b.onclick = () => {
    color = b.dataset.color; if (tool === 'eraser') { tool = 'pen'; $$('[data-tool]', root).forEach(x => x.classList.toggle('on', x.dataset.tool === 'pen')); }
    $$('[data-color]', root).forEach(x => x.classList.toggle('on', x === b));
  });
  $('#skSize').oninput = e => { size = +e.target.value; };
  $('#skUndo').onclick = () => { if (!undo.length) return; redo.push(snap()); ctx.putImageData(undo.pop(), 0, 0); dirty = true; btns(); };
  $('#skRedo').onclick = () => { if (!redo.length) return; undo.push(snap()); ctx.putImageData(redo.pop(), 0, 0); dirty = true; btns(); };
  $('#skClear').onclick = () => { pushUndo(); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, SK.W, SK.H); dirty = true; };

  const close = () => { window.removeEventListener('resize', onResize); root.hidden = true; root.innerHTML = ''; document.body.classList.remove('noscroll'); openSketch.requestClose = null; };
  openSketch.requestClose = () => { if (!dirty) close(); else confirmSheet('Discard your changes to this sketch?', 'Discard', close); };
  $('#skX').onclick = () => openSketch.requestClose();
  $('#skSave').onclick = () => {
    let url = cv.toDataURL('image/webp', 0.9);
    if (!url.startsWith('data:image/webp')) url = cv.toDataURL('image/png');
    if (url.length > 900000) url = cv.toDataURL('image/jpeg', 0.8);
    close(); onSave(url);
    if (url.length > 900000) toast('Large sketch — it may not sync to the cloud');
  };
}

/* ---------- cloud: Firebase Auth + Firestore (REST) ---------- */
let syncing = false, syncT = null, syncAgain = false;
const cloudOn = () => !!(cfg.apiKey && cfg.projectId);
const friendly = m => {
  m = String(m || '');
  if (/EMAIL_EXISTS/.test(m)) return 'That email already has an account. Use Sign in.';
  if (/INVALID_LOGIN_CREDENTIALS|INVALID_PASSWORD|EMAIL_NOT_FOUND/.test(m)) return 'Wrong email or password.';
  if (/WEAK_PASSWORD/.test(m)) return 'Password must be at least 6 characters.';
  if (/INVALID_EMAIL/.test(m)) return 'That email address isn\'t valid.';
  if (/OPERATION_NOT_ALLOWED|ADMIN_ONLY/.test(m)) return 'Enable Email/Password sign-in in Firebase Authentication.';
  if (/API key not valid|API_KEY_INVALID|INVALID_API_KEY/i.test(m)) return 'The Firebase API key isn\'t valid.';
  if (/TOO_MANY_ATTEMPTS/.test(m)) return 'Too many attempts. Try again later.';
  if (/PERMISSION_DENIED|Missing or insufficient/i.test(m)) return 'Firestore denied access. Check the security rules in Setup.';
  if (/NOT_FOUND|does not exist/i.test(m)) return 'Create a Firestore database in your Firebase project first.';
  if (/Failed to fetch|NetworkError|Load failed/i.test(m)) return 'No internet connection.';
  return m || 'Something went wrong.';
};
async function authCall(endpoint, body) {
  const r = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:${endpoint}?key=${encodeURIComponent(cfg.apiKey)}`,
    { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(friendly(j.error && j.error.message));
  return j;
}
function setAuth(j, email) {
  auth = { email: email || (auth && auth.email), uid: j.localId || j.user_id, idToken: j.idToken || j.id_token,
    refreshToken: j.refreshToken || j.refresh_token, exp: now() + (+(j.expiresIn || j.expires_in) || 3600) * 1000 - 60000 };
  DB.set('auth', auth);
}
async function ensureToken() {
  if (!auth) throw new Error('Not signed in');
  if (now() < auth.exp) return;
  const r = await fetch(`https://securetoken.googleapis.com/v1/token?key=${encodeURIComponent(cfg.apiKey)}`,
    { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'grant_type=refresh_token&refresh_token=' + encodeURIComponent(auth.refreshToken) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { auth = null; DB.set('auth', null); renderChip(); throw new Error('Session expired. Please sign in again.'); }
  setAuth(j);
}
async function fs(method, path, body) {
  await ensureToken();
  const r = await fetch(`https://firestore.googleapis.com/v1/projects/${encodeURIComponent(cfg.projectId)}/databases/(default)/documents/users/${auth.uid}${path}`,
    { method, headers: { Authorization: 'Bearer ' + auth.idToken, 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(friendly((j.error && (j.error.status + ' ' + j.error.message)) || 'HTTP ' + r.status));
  return j;
}
async function listCol(col) {
  const out = []; let token = '';
  do {
    const j = await fs('GET', `/${col}?pageSize=200${token ? '&pageToken=' + encodeURIComponent(token) : ''}`);
    (j.documents || []).forEach(d => { try { out.push(JSON.parse(d.fields.json.stringValue)); } catch (e) { /* skip bad doc */ } });
    token = j.nextPageToken || '';
  } while (token);
  return out;
}
const pushDoc = (col, o) => fs('PATCH', `/${col}/${o.id}`, { fields: { json: { stringValue: JSON.stringify(o) }, updatedAt: { integerValue: String(o.updatedAt || 0) } } });

async function syncNow(manual) {
  if (!auth || !cloudOn()) { if (manual) toast('Sign in on the Cloud tab first'); return; }
  if (syncing) { syncAgain = true; return; }
  syncing = true; syncMeta.error = ''; renderChip(); if (tab === 'cloud') renderCloud();
  try {
    const startedDirty = syncMeta.dirty; syncMeta.dirty = false;
    let failedPush = 0;
    for (const col of ['videos', 'playlists', 'notes']) {
      const remote = await listCol(col);
      const rmap = new Map(remote.map(o => [o.id, o]));
      const local = data[col], lmap = new Map(local.map(o => [o.id, o]));
      const merged = [];
      for (const id of new Set([...rmap.keys(), ...lmap.keys()])) {
        const l = lmap.get(id), r = rmap.get(id);
        if (l && (!r || (l.updatedAt || 0) > (r.updatedAt || 0))) {
          try { await pushDoc(col, l); } catch (e) { failedPush++; syncMeta.error = e.message; }
          merged.push(l);
        } else merged.push(r || l);
      }
      data[col] = merged;
    }
    if (failedPush) throw new Error(syncMeta.error || 'Some items could not be uploaded.');
    syncMeta.last = now(); void startedDirty;
    await persist(); await DB.set('meta', syncMeta);
    if (manual) toast('Synced');
  } catch (e) {
    syncMeta.error = e.message || String(e); syncMeta.dirty = true;
    if (manual) toast(syncMeta.error, 4000);
  } finally {
    syncing = false; await DB.set('meta', syncMeta);
    renderAll(true);
    if (!$('#noteView').hidden && !document.activeElement.matches('textarea,input')) renderNote();
    if (syncAgain) { syncAgain = false; scheduleSync(1500); }
  }
}
function scheduleSync(ms) {
  if (!auth || !cloudOn()) return;
  clearTimeout(syncT); syncT = setTimeout(() => syncNow(false), ms || 4000);
}

function renderCloud() {
  const el = $('#tab-cloud');
  const typing = el.contains(document.activeElement) && document.activeElement.matches('input');
  if (typing) return;
  const rules = `rules_version = '2';\nservice cloud.firestore {\n  match /databases/{db}/documents {\n    match /users/{uid}/{doc=**} {\n      allow read, write: if request.auth != null && request.auth.uid == uid;\n    }\n  }\n}`;
  let top;
  if (auth) {
    top = `<div class="card"><h3>Cloud sync</h3><p>Your videos, playlists, notes and sketches sync to your Firebase project.</p>
      <div class="kv"><span>Account</span><span>${esc(auth.email)}</span></div>
      <div class="kv"><span>Status</span><span>${syncing ? 'Syncing…' : syncMeta.error ? esc(syncMeta.error) : syncMeta.dirty ? 'Changes waiting to upload' : 'Up to date'}</span></div>
      <div class="kv"><span>Last sync</span><span>${syncMeta.last ? new Date(syncMeta.last).toLocaleString() : 'Never'}</span></div>
      <div class="kv"><span>Project</span><span>${esc(cfg.projectId)}</span></div>
      <div class="two" style="margin-top:12px"><button class="btn primary" data-action="sync-now">${ic('sync')} Sync now</button><button class="btn" data-action="sign-out">Sign out</button></div></div>`;
  } else if (cloudOn()) {
    top = `<div class="card"><h3>Sign in to sync</h3><p>Use the same account on every phone to share your library.</p>
      <form id="authForm"><div><label>Email</label><input type="email" id="aEmail" autocomplete="email" required></div>
      <div><label>Password</label><input type="password" id="aPass" autocomplete="current-password" minlength="6" required></div>
      <div class="two"><button class="btn primary" type="submit" data-mode="in">Sign in</button><button class="btn" type="submit" data-mode="up">Create account</button></div>
      ${syncMeta.error ? `<p style="color:var(--err)">${esc(syncMeta.error)}</p>` : ''}</form>
      <p style="margin-top:12px"><button class="btn sm" data-action="edit-fb">Change Firebase project</button></p></div>`;
  } else {
    top = `<div class="card"><h3>Connect your cloud</h3><p>Your data is saved on this phone now. Enter your Firebase project to back it up and sync across devices (steps below).</p>
      <form id="cfgForm"><div><label>Firebase Web API key</label><input type="text" id="cKey" autocapitalize="off" autocomplete="off" spellcheck="false"></div>
      <div><label>Project ID</label><input type="text" id="cProj" autocapitalize="off" autocomplete="off" spellcheck="false"></div>
      <button class="btn primary block" type="submit">Save</button></form></div>`;
  }
  el.innerHTML = top + `<details ${cloudOn() ? '' : 'open'}><summary>Setup guide (2 minutes)</summary><ol>
      <li>Go to <b>console.firebase.google.com</b> and create a project (free Spark plan).</li>
      <li><b>Build → Authentication → Get started</b>, enable <b>Email/Password</b>.</li>
      <li><b>Build → Firestore Database → Create database</b> (production mode).</li>
      <li>Open the <b>Rules</b> tab, paste these rules, and Publish:<pre>${esc(rules)}</pre></li>
      <li><b>Project settings → General</b>: copy the <b>Project ID</b> and the <b>Web API key</b> into the form above.</li>
      <li>Create an account here, then sign in with the same email on your other devices.</li></ol></details>
    <details><summary>About this prototype</summary><ol><li>Everything also works offline; changes upload when you're online.</li><li>If two devices edit the same item, the most recent edit wins.</li><li>Sketches are stored inside their notes.</li></ol></details>`;
  const cf = $('#cfgForm');
  if (cf) { $('#cKey').value = cfg.apiKey; $('#cProj').value = cfg.projectId;
    cf.onsubmit = e => { e.preventDefault(); cfg = { apiKey: $('#cKey').value.trim(), projectId: $('#cProj').value.trim() }; DB.set('cfg', cfg); toast('Saved'); renderCloud(); }; }
  const af = $('#authForm');
  if (af) af.onsubmit = async e => {
    e.preventDefault();
    const mode = (e.submitter && e.submitter.dataset.mode) || 'in';
    const email = $('#aEmail').value.trim(), password = $('#aPass').value;
    $$('button', af).forEach(b => b.disabled = true);
    try {
      const j = await authCall(mode === 'up' ? 'signUp' : 'signInWithPassword', { email, password, returnSecureToken: true });
      setAuth(j, email); syncMeta.error = ''; toast(mode === 'up' ? 'Account created' : 'Signed in'); renderChip(); renderCloud(); syncNow(false);
    } catch (err) { syncMeta.error = err.message; renderCloud(); }
  };
}

/* ---------- events ---------- */
document.addEventListener('click', e => {
  const el = e.target.closest('[data-action]'); if (!el) return;
  const a = el.dataset.action, id = el.dataset.id, b = el.dataset.b;
  switch (a) {
    case 'goto-cloud': setTab('cloud'); break;
    case 'play': play(id, null); break;
    case 'play-in-pl': play(id, openPl); break;
    case 'vid-pl': pickPlaylistSheet(id); break;
    case 'vid-note': newNote(id); break;
    case 'vid-del': confirmSheet('Remove this video from your library? It is also removed from playlists.', 'Remove', () => {
      const v = vid(id); v.deleted = true; touch(v);
      data.playlists.forEach(p => { if (p.items.includes(id)) { p.items = p.items.filter(x => x !== id); touch(p); } });
      if (playCtx.videoId === id) stopPlayer(); renderAll(); }); break;
    case 'new-playlist': promptSheet('New playlist', 'Playlist name', '', 'Create', name => { const p = { id: uid(), name, items: [], updatedAt: now() }; data.playlists.push(p); save(); renderAll(); openPl = p.id; renderPlView(); }); break;
    case 'open-pl': openPl = id; miniPref = null; renderPlView(); if (playCtx.videoId) renderDock(); break;
    case 'pl-close': openPl = null; $('#plView').hidden = true; if (playCtx.videoId) renderDock(); break;
    case 'pl-play': { const p = pl(openPl); const f = p.items.find(i => { const v = vid(i); return v && !v.deleted; }); if (f) play(f, p.id); else toast('Playlist is empty'); break; }
    case 'pl-note': { const p = pl(openPl); const f = p.items.find(i => vid(i) && !vid(i).deleted); newNote(f || null); break; }
    case 'pl-rename': { const p = pl(openPl); promptSheet('Rename playlist', 'Playlist name', p.name, 'Save', n => { p.name = n; touch(p); renderAll(); }); break; }
    case 'pl-del': { const p = pl(openPl); confirmSheet('Delete playlist "' + p.name + '"? Your videos stay in the library.', 'Delete', () => { p.deleted = true; touch(p); openPl = null; $('#plView').hidden = true; if (playCtx.plId === p.id) playCtx.plId = null; renderAll(); }); break; }
    case 'pl-up': case 'pl-down': { const p = pl(openPl), i = p.items.indexOf(id), j = i + (a === 'pl-up' ? -1 : 1);
      if (i > -1 && j > -1 && j < p.items.length) { [p.items[i], p.items[j]] = [p.items[j], p.items[i]]; touch(p); renderAll(); } break; }
    case 'pl-rm': { const p = pl(openPl); p.items = p.items.filter(x => x !== id); touch(p); renderAll(); break; }
    case 'new-note': newNote(null); break;
    case 'open-note': openNote(id); break;
    case 'note-close': closeNote(); break;
    case 'note-more': { const n = note(editId);
      sheet('Note options', `<button class="arow" data-a="attach">${ic('video')} ${n.videoId ? 'Change linked video' : 'Attach a video'}</button>
        ${n.videoId ? `<button class="arow" data-a="detach">${ic('close')} Unlink video</button>` : ''}<button class="arow danger" data-a="del">${ic('trash')} Delete note</button>`,
        (box, close) => $$('[data-a]', box).forEach(r => r.onclick = () => { close(); const k = r.dataset.a;
          if (k === 'attach') pickVideoSheet(v => { n.videoId = v; touch(n); renderNote(); });
          if (k === 'detach') { n.videoId = null; touch(n); renderNote(); }
          if (k === 'del') confirmSheet('Delete this note and its sketches?', 'Delete', () => { n.deleted = true; touch(n); editId = null; $('#noteView').hidden = true; renderAll(); }); })); break; }
    case 'note-attach': pickVideoSheet(v => { const n = note(editId); n.videoId = v; touch(n); renderNote(); }); break;
    case 'play-note': { const n = note(editId); play(n.videoId, null); break; }
    case 'add-text': { const n = note(editId); n.blocks.push({ id: uid(), type: 'text', text: '' }); touch(n); renderNote(true); break; }
    case 'add-sketch': openSketch(null, url => { const n = note(editId); if (!n) return; n.blocks.push({ id: uid(), type: 'sketch', img: url }); touch(n); renderNote(); const bd = $('#nBody'); bd.scrollTop = bd.scrollHeight; }); break;
    case 'edit-sketch': { const bk = blk(b); if (bk) openSketch(bk.img, url => { bk.img = url; touch(note(editId)); renderNote(); }); break; }
    case 'add-ts': addTimestamp(); break;
    case 'add-video': pickVideoSheet(v => { const n = note(editId); n.blocks.push({ id: uid(), type: 'video', videoId: v }); if (!n.videoId) n.videoId = v; touch(n); renderNote(); }); break;
    case 'play-ts': { const bk = blk(b); if (bk) play(bk.videoId, null, bk.t); break; }
    case 'play-blk': { const bk = blk(b); if (bk) play(bk.videoId, null); break; }
    case 'blk-more': { const n = note(editId), i = n.blocks.findIndex(x => x.id === b);
      sheet('Block', `${n.blocks[i].type === 'sketch' ? `<button class="arow" data-a="edit">${ic('brush')} Edit sketch</button>` : ''}
        <button class="arow" data-a="up" ${i === 0 ? 'disabled' : ''}>${ic('up')} Move up</button><button class="arow" data-a="down" ${i === n.blocks.length - 1 ? 'disabled' : ''}>${ic('down')} Move down</button>
        <button class="arow danger" data-a="del">${ic('trash')} Delete</button>`,
        (box, close) => $$('[data-a]', box).forEach(r => r.onclick = () => { close(); const k = r.dataset.a;
          const j = n.blocks.findIndex(x => x.id === b);
          if (k === 'edit') { const bk = n.blocks[j]; openSketch(bk.img, url => { bk.img = url; touch(n); renderNote(); }); return; }
          if (k === 'up' && j > 0) [n.blocks[j - 1], n.blocks[j]] = [n.blocks[j], n.blocks[j - 1]];
          if (k === 'down' && j < n.blocks.length - 1) [n.blocks[j + 1], n.blocks[j]] = [n.blocks[j], n.blocks[j + 1]];
          if (k === 'del') n.blocks.splice(j, 1);
          touch(n); renderNote(); })); break; }
    case 'dock-prev': nextInList(-1); break;
    case 'dock-next': nextInList(1); break;
    case 'dock-size': miniPref = !isMini(); renderDock(); break;
    case 'dock-close': stopPlayer(); break;
    case 'sync-now': syncNow(true); break;
    case 'sign-out': auth = null; DB.set('auth', null); syncMeta.error = ''; renderChip(); renderCloud(); break;
    case 'edit-fb': cfg = { apiKey: '', projectId: '' }; DB.set('cfg', cfg); renderCloud(); break;
  }
});

document.addEventListener('input', e => {
  const t = e.target;
  if (t.matches('textarea[data-blk]')) { const bk = blk(t.dataset.blk); if (bk) { bk.text = t.value; touch(note(editId)); } autosize(t); }
  else if (t.matches('[data-ts]')) { const bk = blk(t.dataset.ts); if (bk) { bk.text = t.value; touch(note(editId)); } }
  else if (t.id === 'nTitle') { const n = note(editId); if (n) { n.title = t.value; touch(n); } }
  else if (t.id === 'vSearch') { vFilter = t.value.trim().toLowerCase(); renderVideos(); }
  else if (t.id === 'nSearch') { nFilter = t.value.trim().toLowerCase(); renderNotes(); }
});

$('#tabbar').addEventListener('click', e => { const i = $$('#tabbar button').indexOf(e.target.closest('button')); if (i > -1) setTab(TABS[i][0]); });
$('#addForm').addEventListener('submit', async e => {
  e.preventDefault(); const inp = $('#addUrl'); const txt = inp.value.trim(); if (!txt) return;
  const v = await addVideoFromText(txt); if (v) inp.value = '';
});

window.onAndroidBack = function () {
  const sheets = $$('.sheet-wrap'); if (sheets.length) { sheets[sheets.length - 1].remove(); return true; }
  if (!$('#sketchView').hidden) { if (openSketch.requestClose) openSketch.requestClose(); return true; }
  if (!$('#noteView').hidden) { closeNote(); return true; }
  if (!$('#plView').hidden) { openPl = null; $('#plView').hidden = true; if (playCtx.videoId) renderDock(); return true; }
  if (tab !== 'videos') { setTab('videos'); return true; }
  return false;
};
window.onSharedText = async function (text) {
  setTab('videos'); const v = await addVideoFromText(text, true);
  if (v) toast('Added "' + (v.title || 'video') + '"');
};
document.addEventListener('visibilitychange', () => { if (!document.hidden && auth) scheduleSync(800); });
window.addEventListener('online', () => scheduleSync(800));

/* ---------- boot ---------- */
(async function init() {
  $('#addForm button').innerHTML = ic('plus') + 'Add';
  $('[data-action="new-playlist"]').innerHTML = ic('plus') + ' New playlist';
  $('.fab').innerHTML = ic('plus');
  await DB.open();
  const d = await DB.get('data'); if (d) data = Object.assign({ videos: [], playlists: [], notes: [] }, d);
  const c = await DB.get('cfg'); const defs = window.VIDNOTES_DEFAULTS || {};
  cfg = c && (c.apiKey || c.projectId) ? c : { apiKey: defs.apiKey || '', projectId: defs.projectId || '' };
  auth = await DB.get('auth');
  const m = await DB.get('meta'); if (m) syncMeta = Object.assign(syncMeta, m, { error: '' });
  setTab('videos'); renderAll();
  if (window.__pendingShared) { const t = window.__pendingShared; window.__pendingShared = null; window.onSharedText(t); }
  if (auth) scheduleSync(1200);
})();

})();
