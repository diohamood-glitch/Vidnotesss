// Optional: bake your Firebase project into the APK so you don't have to type it on the phone.
// Leave empty to enter these values in the app's "Cloud" tab instead.
// (The Firebase Web API key is a public identifier, not a secret; access is protected by the
// Firestore security rules described in README.md.)
window.VIDNOTES_DEFAULTS = {
  apiKey: "",
  projectId: ""
};
